-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 10-05-2013 a las 12:00:04
-- Versión del servidor: 5.0.95
-- Versión de PHP: 5.1.6

SET FOREIGN_KEY_CHECKS=0;

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `promocion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `escuela`
--

DROP TABLE IF EXISTS `escuela`;
CREATE TABLE IF NOT EXISTS `escuela` (
  `id_escuela` int(10) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `comentario` varchar(99) NOT NULL,
  `abrev` varchar(5) NOT NULL,
  PRIMARY KEY  (`id_escuela`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

DROP TABLE IF EXISTS `estados`;
CREATE TABLE IF NOT EXISTS `estados` (
  `id_estado` char(2) NOT NULL,
  `estado` char(30) NOT NULL,
  PRIMARY KEY  (`id_estado`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus`
--

DROP TABLE IF EXISTS `estatus`;
CREATE TABLE IF NOT EXISTS `estatus` (
  `id_estatus` int(7) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  `estatus` enum('activo','inactivo') NOT NULL,
  `abrev` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_estatus`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medio`
--

DROP TABLE IF EXISTS `medio`;
CREATE TABLE IF NOT EXISTS `medio` (
  `id_medio` int(10) NOT NULL auto_increment,
  `nombre` varchar(30) default NULL,
  `estatus` enum('activo','inactivo') default NULL,
  `comentario` varchar(99) NOT NULL,
  PRIMARY KEY  (`id_medio`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

DROP TABLE IF EXISTS `municipios`;
CREATE TABLE IF NOT EXISTS `municipios` (
  `id_estado` char(2) NOT NULL,
  `id_municipio` char(4) NOT NULL,
  `municipio` char(60) NOT NULL,
  KEY `id_estado` (`id_estado`),
  KEY `id_municipio` (`id_municipio`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

DROP TABLE IF EXISTS `persona`;
CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(10) NOT NULL auto_increment,
  `nombre` varchar(30) default NULL,
  `apellido_pat` varchar(30) default NULL,
  `apellido_mat` varchar(30) default NULL,
  `sexo` varchar(10) default NULL,
  `tel_casa` varchar(30) default NULL,
  `tel_celular` varchar(30) default NULL,
  `observaciones` varchar(30) default NULL,
  `estatus` varchar(30) default NULL,
  `mail` varchar(30) default NULL,
  `id_municipio` int(10) default NULL,
  `id_escuela` int(10) default NULL,
  `id_medio` int(5) NOT NULL,
  `id_usuario` int(2) NOT NULL,
  `contestado` int(2) NOT NULL default '0',
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguimiento`
--

DROP TABLE IF EXISTS `seguimiento`;
CREATE TABLE IF NOT EXISTS `seguimiento` (
  `id_seguimiento` int(10) NOT NULL auto_increment,
  `fecha` timestamp NULL default CURRENT_TIMESTAMP,
  `fecha_seguimiento` date default NULL,
  `observacion` varchar(30) default NULL,
  `prioridad` varchar(30) default NULL,
  `id_persona` int(10) default NULL,
  `id_usuario` int(10) default NULL,
  `id_medio` int(10) default NULL,
  `contestado` int(2) NOT NULL default '0',
  `estatus` varchar(30) default NULL,
  PRIMARY KEY  (`id_seguimiento`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(10) NOT NULL auto_increment,
  `nombre` varchar(30) default NULL,
  `apellido_pat` varchar(30) default NULL,
  `apellido_mat` varchar(30) default NULL,
  `estatus` varchar(30) default NULL,
  `usuario` varchar(30) default NULL,
  `contrasena` varchar(50) default NULL,
  `matricula` int(10) default NULL,
  `tipo` enum('Administrador','Director','Capturista') NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

SET FOREIGN_KEY_CHECKS=1;
